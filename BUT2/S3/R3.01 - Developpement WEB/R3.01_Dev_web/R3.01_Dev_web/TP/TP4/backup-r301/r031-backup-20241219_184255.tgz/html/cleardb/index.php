<?php 

require_once __DIR__ . '/../../config/database.php';

$database = new Database();
$dbh = $database->getConnection();

$dbh->exec("DELETE FROM matches_poules");
$dbh->exec("DELETE FROM equipes");
echo "Base de données nettoyée.";


$dbh = null;
?>