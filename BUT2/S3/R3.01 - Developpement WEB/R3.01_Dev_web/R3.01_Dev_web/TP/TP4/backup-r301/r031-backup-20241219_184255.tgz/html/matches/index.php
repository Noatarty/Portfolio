<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../controllers/match_poule_controller.php';
$database = new Database();
$db = $database->getConnection();
$match_poulesController = new MatchPouleController($db);
$stmt = $match_poulesController->listMatchsPoules();
$match_poules = [];
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $match_poules[] = $row;
}
require_once __DIR__ . '/../../views/match_poules_list.php';
?>