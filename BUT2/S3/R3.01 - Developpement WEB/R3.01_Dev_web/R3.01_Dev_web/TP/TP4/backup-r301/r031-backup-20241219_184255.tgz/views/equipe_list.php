<?php
// Supposons que $trips soit un tableau d'objets Trip passé à cette vue
if (!empty($equipes)) { ?>
    <h1>Liste des equipes</h1>
    <table>
        <tr>
            <th>Code</th>
            <th>Nom</th>
            <th>Poule</th>
        </tr>
        <?php foreach ($equipes as $equipes) { ?>
            <tr>
                <td><?php echo htmlentities($equipes['code']); ?></td>
                <td><?php echo htmlentities($equipes['nom']); ?></td>
                <td><?php echo htmlentities($equipes['poule']); ?></td>
            </tr>
        <?php } ?>
    </table>
<?php } else { ?>
    <p>Aucune equipe trouvée.</p>
<?php } ?>