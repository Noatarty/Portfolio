<?php 

require_once __DIR__ . '/../../config/database.php';

$database = new Database();
$dbh = $database->getConnection();

// Remplir les équipes
$equipes = file('../EQUIPES', FILE_IGNORE_NEW_LINES);
foreach ($equipes as $equipe) {
    // Extraire la poule et les équipes
    $parts = explode('=', $equipe);
    $poule = trim($parts[0]); // Nettoyer la poule
    $poule = substr($poule, -1); // Obtenir le dernier caractère de la poule
    $equipes_list = $parts[1]; // Liste des équipes

    $equipes_array = explode(',', $equipes_list); // Séparer les équipes

    foreach ($equipes_array as $equipe) {
        $data = explode('/', $equipe);
        $code = $data[0];
        $nom = $data[1];

        // Préparer et exécuter la requête d'insertion
        $stmt = $dbh->prepare("INSERT INTO equipes (code, nom, poule) VALUES (?, ?, ?)");
        $stmt->execute([$code, $nom, $poule]);
    }
}

// Remplir les matchs de poules
$matches = file('../MATCHES', FILE_IGNORE_NEW_LINES);
foreach ($matches as $match) {
    $parts = explode('=', $match);
    $codes = $parts[0];
    $details = $parts[1];

    $codes_array = explode('-', $codes);
    $code_equipe_1 = $codes_array[0];
    $code_equipe_2 = $codes_array[1];

    $details_array = explode(',', $details);
    $date = $details_array[0];
    $score = explode('-', $details_array[1]);
    $points = explode('-', $details_array[2]);

    $score_equipe_1 = $score[0];
    $score_equipe_2 = $score[1];
    $points_equipe_1 = $points[0];
    $points_equipe_2 = $points[1];

    // Préparer et exécuter la requête d'insertion
    $stmt = $dbh->prepare("INSERT INTO matches_poules (code_equipe_1, code_equipe_2, date_match, score_equipe_1, score_equipe_2, points_equipe_1, points_equipe_2) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$code_equipe_1, $code_equipe_2, date('Y-m-d', strtotime($date)), (int)$score_equipe_1, (int)$score_equipe_2, (int)$points_equipe_1, (int)$points_equipe_2]);
}

echo "Base de données remplie avec succès.";

$dbh = null;
?>