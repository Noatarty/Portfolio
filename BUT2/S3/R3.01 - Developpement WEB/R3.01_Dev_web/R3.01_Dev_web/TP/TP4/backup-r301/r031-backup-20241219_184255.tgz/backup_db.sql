-- MariaDB dump 10.19  Distrib 10.11.6-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: mariadb    Database: r301_td3
-- ------------------------------------------------------
-- Server version	11.0.3-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `equipes`
--

DROP TABLE IF EXISTS `equipes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(3) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `poule` varchar(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipes`
--

LOCK TABLES `equipes` WRITE;
/*!40000 ALTER TABLE `equipes` DISABLE KEYS */;
INSERT INTO `equipes` VALUES
(22,'NZL','Nouvelle-Zelande','A'),
(23,'FRA','France','A'),
(24,'ITA','Italie','A'),
(25,'URU','Uruguay','A'),
(26,'NAM','Namibie','A'),
(27,'RSA','Afrique du Sud','B'),
(28,'IRL','Irlande','B'),
(29,'SCO','Ecosse','B'),
(30,'TGA','Tonga','B'),
(31,'ROU','Roumanie','B'),
(32,'WAL','Pays de Galles','C'),
(33,'AUS','Australie','C'),
(34,'FIJ','Fidji','C'),
(35,'GEO','Georgie','C'),
(36,'POR','Portugal','C'),
(37,'ENG','Angleterre','D'),
(38,'JPN','Japon','D'),
(39,'ARG','Argentine','D'),
(40,'SAM','Samoa','D'),
(41,'CHI','Chili','D');
/*!40000 ALTER TABLE `equipes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matches_finale`
--

DROP TABLE IF EXISTS `matches_finale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matches_finale` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_equipe_1` varchar(3) NOT NULL,
  `code_equipe_2` varchar(3) NOT NULL,
  `date_match` date NOT NULL,
  `score_equipe_1` int(11) DEFAULT 0,
  `score_equipe_2` int(11) DEFAULT 0,
  `points_equipe_1` int(11) DEFAULT 0,
  `points_equipe_2` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `code_equipe_1` (`code_equipe_1`),
  KEY `code_equipe_2` (`code_equipe_2`),
  CONSTRAINT `matches_finale_ibfk_1` FOREIGN KEY (`code_equipe_1`) REFERENCES `equipes` (`code`),
  CONSTRAINT `matches_finale_ibfk_2` FOREIGN KEY (`code_equipe_2`) REFERENCES `equipes` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matches_finale`
--

LOCK TABLES `matches_finale` WRITE;
/*!40000 ALTER TABLE `matches_finale` DISABLE KEYS */;
/*!40000 ALTER TABLE `matches_finale` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matches_poules`
--

DROP TABLE IF EXISTS `matches_poules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matches_poules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code_equipe_1` varchar(3) NOT NULL,
  `code_equipe_2` varchar(3) NOT NULL,
  `date_match` date NOT NULL,
  `score_equipe_1` int(11) DEFAULT 0,
  `score_equipe_2` int(11) DEFAULT 0,
  `points_equipe_1` int(11) DEFAULT 0,
  `points_equipe_2` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `code_equipe_1` (`code_equipe_1`),
  KEY `code_equipe_2` (`code_equipe_2`),
  CONSTRAINT `matches_poules_ibfk_1` FOREIGN KEY (`code_equipe_1`) REFERENCES `equipes` (`code`),
  CONSTRAINT `matches_poules_ibfk_2` FOREIGN KEY (`code_equipe_2`) REFERENCES `equipes` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matches_poules`
--

LOCK TABLES `matches_poules` WRITE;
/*!40000 ALTER TABLE `matches_poules` DISABLE KEYS */;
INSERT INTO `matches_poules` VALUES
(1,'FRA','NZL','2023-08-09',27,13,4,0),
(2,'ITA','NAM','2023-09-09',52,8,5,0),
(3,'IRL','ROU','2023-09-09',82,8,5,0),
(4,'AUS','GEO','2023-09-09',35,15,5,0),
(5,'ENG','ARG','2023-09-09',27,10,4,0),
(6,'JPN','CHI','2023-10-09',42,12,5,0),
(7,'RSA','SCO','2023-10-09',18,3,4,0),
(8,'WAL','FIJ','2023-10-09',32,26,5,2),
(9,'FRA','URU','1970-01-01',27,12,4,0),
(10,'NZL','NAM','1970-01-01',71,3,5,0),
(11,'SAM','CHI','1970-01-01',43,10,5,0),
(12,'WAL','POR','1970-01-01',28,8,5,0),
(13,'IRL','TGA','1970-01-01',59,16,5,0),
(14,'RSA','ROU','1970-01-01',76,0,5,0),
(15,'AUS','FIJ','1970-01-01',15,22,1,4),
(16,'ENG','JPN','1970-01-01',34,12,5,0),
(17,'ITA','URU','1970-01-01',38,17,5,0),
(18,'FRA','NAM','1970-01-01',96,0,5,0),
(19,'ARG','SAM','1970-01-01',19,10,4,0),
(20,'GEO','POR','1970-01-01',18,18,1,1),
(21,'ENG','CHI','1970-01-01',71,0,5,0),
(22,'RSA','IRL','1970-01-01',8,13,1,4),
(23,'SCO','TGA','1970-01-01',45,17,5,0),
(24,'WAL','AUS','1970-01-01',40,6,4,0),
(25,'URU','NAM','1970-01-01',36,26,5,0),
(26,'JPN','SAM','1970-01-01',28,22,4,1),
(27,'NZL','ITA','1970-01-01',96,17,5,0),
(28,'ARG','CHI','1970-01-01',59,5,5,0),
(29,'FIJ','GEO','1970-01-01',17,12,4,1),
(30,'SCO','ROU','1970-01-01',84,0,5,0),
(31,'AUS','POR','2023-01-10',34,14,5,0),
(32,'RSA','TGA','2023-01-10',49,18,5,0),
(33,'NZL','URU','2023-05-10',73,0,5,0),
(34,'FRA','ITA','2023-06-10',60,7,5,0),
(35,'WAL','GEO','2023-07-10',43,19,5,0),
(36,'ENG','SAM','2023-07-10',18,17,4,0),
(37,'IRL','SCO','2023-07-10',36,14,5,0),
(38,'JPN','ARG','2023-08-10',27,39,0,5),
(39,'TGA','ROU','2023-08-10',45,24,5,0),
(40,'FIJ','POR','2023-08-10',23,24,1,4);
/*!40000 ALTER TABLE `matches_poules` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-19 18:42:55
