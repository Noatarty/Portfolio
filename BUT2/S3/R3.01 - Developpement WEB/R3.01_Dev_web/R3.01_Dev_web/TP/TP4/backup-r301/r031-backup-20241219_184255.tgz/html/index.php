<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../controllers/equipe_controller.php';
$database = new Database();
$db = $database->getConnection();
$equipeController = new EquipeController($db);
$stmt = $equipeController->listPays();
$pays = [];
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $pays[] = $row;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coupe du Monde de Rugby 2023</title>
    <link rel="stylesheet" href="styles.css"> <!-- Lien vers votre fichier CSS si nécessaire -->
</head>
<body>
<h1>Coupe du Monde de Rugby 2023</h1>

    <nav>
        <ul>
            <li><a href="http://localhost:8000/filldb/">Remplir la base de données</a></li>
            <li><a href="http://localhost:8000/cleardb/">Vider la base de données</a></li>
            <li><a href="http://localhost:8000/matches/">Afficher les matches de poules</a></li> <!-- Ajoutez d'autres liens si nécessaire -->
        </ul>
    </nav>

<?php
// Supposons que $trips soit un tableau d'objets Trip passé à cette vue
if (!empty($pays)) { ?>
    <h2>liste des pays de la compétition</h2>
    <?php
    foreach ($pays as $pays) { ?>
        <p><?php echo htmlentities($pays['nom']); ?></p>
    <?php } ?>
<?php } else { ?>
    <p>Aucune equipe trouvée.</p>
<?php } ?>
</body>