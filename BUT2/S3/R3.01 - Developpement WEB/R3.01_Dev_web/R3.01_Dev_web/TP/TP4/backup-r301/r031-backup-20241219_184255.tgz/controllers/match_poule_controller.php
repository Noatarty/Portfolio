<?php
require_once __DIR__ . '/../models/match_poule.php';

class MatchPouleController {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    // Lister tous les matchs de poule
    public function listMatchsPoules() {
        $match = new MatchPoule($this->db);
        return $match->read();
    }

    // Ajouter un match de poule
    public function addMatchPoule($code_equipe_1, $code_equipe_2, $date_match, $score_equipe_1, $score_equipe_2, $points_equipe_1, $points_equipe_2) {
        $match = new MatchPoule($this->db);
        $match->code_equipe_1 = $code_equipe_1;
        $match->code_equipe_2 = $code_equipe_2;
        $match->date_match = $date_match;
        $match->score_equipe_1 = $score_equipe_1;
        $match->score_equipe_2 = $score_equipe_2;
        $match->points_equipe_1 = $points_equipe_1;
        $match->points_equipe_2 = $points_equipe_2;
        return $match->create();
    }

    // Modifier un match de poule
    public function alterMatchPoule($id, $code_equipe_1, $code_equipe_2, $date_match, $score_equipe_1, $score_equipe_2, $points_equipe_1, $points_equipe_2) {
        $match = new MatchPoule($this->db);
        $match->id = $id;
        $match->code_equipe_1 = $code_equipe_1;
        $match->code_equipe_2 = $code_equipe_2;
        $match->date_match = $date_match;
        $match->score_equipe_1 = $score_equipe_1;
        $match->score_equipe_2 = $score_equipe_2;
        $match->points_equipe_1 = $points_equipe_1;
        $match->points_equipe_2 = $points_equipe_2;
        return $match->update();
    }

    // Supprimer un match de poule
    public function deleteMatchPoule($id) {
        $match = new MatchPoule($this->db);
        $match->id = $id;
        return $match->delete();
    }

    // Lister les matchs regroupés par date
public function listMatchsByDate() {
    $match = new MatchPoule($this->db);
    $allMatches = $match->read(); // Supposons que read() retourne un tableau d'objets Match

    // Regrouper les matchs par date
    $matchesByDate = [];

    foreach ($allMatches as $match) {
        $date = $match['date_match'];
        if (!isset($matchesByDate[$date])) {
            $matchesByDate[$date] = [];
        }
        $matchesByDate[$date][] = $match;
    }

    return $matchesByDate;
}

public function getTeamNameByCode($code) {
    $query = "SELECT nom FROM equipes WHERE code = :code";
    $stmt = $this->db->prepare($query);
    $stmt->bindParam(':code', $code, PDO::PARAM_STR);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    return $result['nom'] ?? 'Nom inconnu';
}

}
?>
