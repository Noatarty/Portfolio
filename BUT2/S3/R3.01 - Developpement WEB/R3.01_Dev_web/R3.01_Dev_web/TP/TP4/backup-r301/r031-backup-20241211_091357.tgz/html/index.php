<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../models/equipe.php';
require_once __DIR__ . '/../models/match_poule.php';
require_once __DIR__ . '/../models/match_finale.php';

// Connexion à la base de données
$database = new Database();
$conn = $database->getConnection();

// --- Affichage des équipes ---
$equipe = new Equipe($conn);
$teams = $equipe->read()->fetchAll(PDO::FETCH_ASSOC);

// --- Affichage des matchs de poule ---
$matchPoule = new MatchPoule($conn);
$poolMatches = $matchPoule->read()->fetchAll(PDO::FETCH_ASSOC);

// --- Affichage des matchs de la phase finale ---
$matchFinale = new MatchFinale($conn);
$finalMatches = $matchFinale->read()->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coupe du Monde de Rugby 2023</title>
    <style>
        body { font-family: Arial, sans-serif; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: center; }
        th { background-color: #f2f2f2; }
        h2 { margin-top: 30px; }
    </style>
</head>
<body>
    <h1>Coupe du Monde de Rugby 2023</h1>

    <!-- Affichage des équipes -->
    <h2>Équipes</h2>
    <table>
        <tr>
            <th>Code</th>
            <th>Nom</th>
            <th>Poule</th>
        </tr>
        <?php foreach ($teams as $team): ?>
            <tr>
                <td><?php echo htmlspecialchars($team['code']); ?></td>
                <td><?php echo htmlspecialchars($team['nom']); ?></td>
                <td><?php echo htmlspecialchars($team['poule']); ?></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <!-- Affichage des matchs de poule -->
    <h2>Matchs de Poule</h2>
    <table>
        <tr>
            <th>Date</th>
            <th>Équipe 1</th>
            <th>Score</th>
            <th>Équipe 2</th>
            <th>Points</th>
        </tr>
        <?php foreach ($poolMatches as $match): ?>
            <tr>
                <td><?php echo htmlspecialchars($match['date_match']); ?></td>
                <td><?php echo htmlspecialchars($match['code_equipe_1']); ?></td>
                <td><?php echo htmlspecialchars($match['score_equipe_1']); ?> - <?php echo htmlspecialchars($match['score_equipe_2']); ?></td>
                <td><?php echo htmlspecialchars($match['code_equipe_2']); ?></td>
                <td><?php echo htmlspecialchars($match['points_equipe_1']); ?> - <?php echo htmlspecialchars($match['points_equipe_2']); ?></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <!-- Affichage des matchs de la phase finale -->
    <h2>Matchs de la Phase Finale</h2>
    <table>
        <tr>
            <th>Date</th>
            <th>Équipe 1</th>
            <th>Score</th>
            <th>Équipe 2</th>
        </tr>
        <?php foreach ($finalMatches as $match): ?>
            <tr>
                <td><?php echo htmlspecialchars($match['date_match']); ?></td>
                <td><?php echo htmlspecialchars($match['code_equipe_1']); ?></td>
                <td><?php echo htmlspecialchars($match['score_equipe_1']); ?> - <?php echo htmlspecialchars($match['score_equipe_2']); ?></td>
                <td><?php echo htmlspecialchars($match['code_equipe_2']); ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
