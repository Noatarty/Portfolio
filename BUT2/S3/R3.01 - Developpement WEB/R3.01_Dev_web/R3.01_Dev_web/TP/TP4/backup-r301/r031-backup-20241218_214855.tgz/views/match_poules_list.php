<?php
// Supposons que $match_poules soit un tableau d'objets Match passé à cette vue
if (!empty($match_poules)) {
    // Regrouper les matchs par date
    $matchParDate = [];?>
    <h1>Liste des equipes</h1>
    <table border="1">        
        <tr> 
            <th>Date</th>
            <th>Équipe 1</th>
            <th>Score Équipe 1</th>
            <th>Points Équipe 1</th>
            <th>Équipe 2</th>
            <th>Score Équipe 2</th>
            <th>Points Équipe 2</th>
        </tr>
    <?php

    foreach ($matchParDate as $date => $matches) {
        $firstMatch = true; // Pour gérer le rowspan

        foreach ($matches as $match) {
            if ($firstMatch) {
                // Afficher la date avec rowspan 
                ?>
                <tr>
                    <td><?php echo htmlentities($equipes['code']); ?></td>
                    <td><?php echo htmlentities($equipes['nom']); ?></td>
                    <td><?php echo htmlentities($equipes['poule']); ?></td>
                </tr>
                echo "<tr>";
                echo "<td rowspan='" . count($matches) . "'>" . htmlentities($date) . "</td>"; // rowspan pour la date
                echo "<td>" . htmlentities($match->code_equipe_1) . "</td>";
                echo "<td>" . htmlentities($match->score_equipe_1) . "</td>";
                echo "<td>" . htmlentities($match->points_equipe_1) . "</td>";
                echo "<td>" . htmlentities($match->code_equipe_2) . "</td>";
                echo "<td>" . htmlentities($match->score_equipe_2) . "</td>";
                echo "<td>" . htmlentities($match->points_equipe_2) . "</td>";
                echo "</tr>"; <?php
                $firstMatch = false; // Ne pas afficher la date pour les matchs suivants
            } else {
                // Afficher les matchs suivants sans la date
                echo "<tr>";
                echo "<td>" . htmlentities($match->code_equipe_1) . "</td>";
                echo "<td>" . htmlentities($match->score_equipe_1) . "</td>";
                echo "<td>" . htmlentities($match->points_equipe_1) . "</td>";
                echo "<td>" . htmlentities($match->code_equipe_2) . "</td>";
                echo "<td>" . htmlentities($match->score_equipe_2) . "</td>";
                echo "<td>" . htmlentities($match->points_equipe_2) . "</td>";
                echo "</tr>";
            }
        }
    }

    echo '</table>';
} else {
    echo "<p>Aucun match trouvé.</p>";
}
?>