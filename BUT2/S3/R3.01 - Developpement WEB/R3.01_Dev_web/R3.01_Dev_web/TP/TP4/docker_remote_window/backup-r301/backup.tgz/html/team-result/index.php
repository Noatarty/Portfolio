<?php
require_once __DIR__ . '/../../controllers/match_poule_controller.php';
require_once __DIR__ . '/../../config/database.php';
$database = new Database();
$db = $database->getConnection();
// Vérifiez si le code de l'équipe est passé dans l'URL
if (isset($_GET['code'])) {
    $codeEquipe = $_GET['code'];

    // Créer une instance du contrôleur avec la connexion à la base de données
    $controller = new MatchPouleController($db);
    
    // Récupérer les informations de l'équipe
    $teamInfo = $controller->getTeamInfoByCode($codeEquipe);
    print_r($teamInfo);
    ?>
    <table border="1" style="width: 700px;">
            
            
                
            
    </table>
    <?php
} else {
    echo "<p>Code d'équipe manquant.</p>";
}
$db = null;
?>