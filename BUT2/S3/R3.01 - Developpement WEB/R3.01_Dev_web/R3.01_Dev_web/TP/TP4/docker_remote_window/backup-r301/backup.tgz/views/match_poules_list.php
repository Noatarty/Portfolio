<?php
require_once __DIR__ . '/../controllers/match_poule_controller.php';

// Créer une instance du contrôleur avec la connexion à la base de données
$controller = new MatchPouleController($db);
$matchParDate = $controller->listMatchsByDate();

if (!empty($matchParDate)) { ?>
    <h1>Liste des matchs</h1>
    <table border="1" style="width: 700px;">
        <?php foreach ($matchParDate as $date => $matches) { ?>
            <tr>
                <td colspan="9" style="text-align: center; font-weight: bold;"><?php echo htmlentities($date); ?></td>
            </tr>
            
            <?php foreach ($matches as $match) { ?>
                <tr colspan="4" >
                    <td ><img src="./Logos_RWC2023/<?php echo htmlentities($match['code_equipe_1']); ?>.png"></td>
                    <td ><a href="http://localhost:8000/team-result/?code=<?php echo htmlentities($match['code_equipe_1']); ?>"><?php echo htmlentities($controller->getTeamNameByCode($match['code_equipe_1'])); ?></a></td>
                    <td style="background-color: green;" ><?php echo htmlentities($match['score_equipe_1']); ?></td>
                    <td style="background-color: green;" >+<?php echo htmlentities($match['points_equipe_1']); ?></td>
                    <td></td>
                    <td ><img src="./Logos_RWC2023/<?php echo htmlentities($match['code_equipe_2']); ?>.png"></td>
                    <td ><a href="http://localhost:8000/team-result/?code=<?php echo htmlentities($match['code_equipe_1']); ?>"><?php echo htmlentities($controller->getTeamNameByCode($match['code_equipe_2'])); ?></a></td>
                    <td ><?php echo htmlentities($match['score_equipe_2'] ); ?></td>
                    <td ><?php echo htmlentities($match['points_equipe_2']); ?></td>
                </tr>
                
            
            <?php } ?>
        <?php } ?>
    </table>
<?php } else { ?>
    <p>Aucun match trouvé.</p>
<?php } ?> 