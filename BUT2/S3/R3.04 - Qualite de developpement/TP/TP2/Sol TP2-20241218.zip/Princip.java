public class Princip{
	public static void main(String[] args){
		PizzeriaBrest MaPizzeria = new PizzeriaBrest("Chez Enzo");
	        PizzaFromage p= MaPizzeria.CommanderPizzaFromage();
	        System.out.println(p);
	}
}