abstract class Pate{
  String type;
   public Pate(String n){
      type=n;
   }
}

class PateFine extends Pate{
  public PateFine(){
     super("pateFine");
  }
}

abstract class ModeCuisson{
  String mode;
   public ModeCuisson(String n){
      mode=n;
   }
}

class CuissonLente extends ModeCuisson{
  public CuissonLente(){
     super("Cuisson Lente");
  }
}

abstract class Fromage{
  String type;
   public Fromage(String n){
      type=n;
   }
}

class DeQuimper extends Fromage{
  public DeQuimper(){
     super("Fromage de Quimper");
  }
}

//*******************************


interface Fabrique{
	public Pate getPate();
	public ModeCuisson getModeCuisson();
        public Fromage getFromage();
}

class FabriqueBretagne implements Fabrique{

    public Pate getPate(){
		return new PateFine();
	}
		
	public ModeCuisson getModeCuisson(){
		return new CuissonLente();
	}

     public Fromage getFromage(){
               return new DeQuimper();
        }
}