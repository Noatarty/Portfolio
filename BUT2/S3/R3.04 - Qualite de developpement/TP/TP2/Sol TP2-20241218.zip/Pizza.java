
abstract class Pizza{
	String nom;
	Pate pate;
	ModeCuisson modeCuisson;
	
	public String toString(){
		StringBuffer affichage = new StringBuffer();
		affichage.append(" ------ "+nom+" ------ \n");
		affichage.append(pate.type+"\n");
		affichage.append(modeCuisson.mode+"\n");
	    return affichage.toString();
	}
	
	public Pizza(String no, Pate p, ModeCuisson mc){
		 nom =no;
		 pate=p;
		 modeCuisson = mc;
		 
	}
}

class PizzaFromage extends Pizza{
        Fromage from;
	public PizzaFromage(Fromage f, Pate p, ModeCuisson mc){
		 super("Pizza Fromage", p, mc);
                 from=f;
	}
        public String toString(){
         return super.toString()+from.type;
        }
}
	