abstract class Pizzeria{
	 String nom;
	 Fabrique fab;

         Pizzeria(String no, Fabrique f){
              nom=no;
              fab=f;
         }

         public void nouvelleFabrique(Fabrique f){
           fab=f;
         }
}

class PizzeriaBrest extends Pizzeria{
	public PizzeriaBrest(String no){
		super(no, new FabriqueBretagne());
	}
	
	PizzaFromage CommanderPizzaFromage(){
		return new PizzaFromage(fab.getFromage(),fab.getPate(), fab.getModeCuisson());
	}
}