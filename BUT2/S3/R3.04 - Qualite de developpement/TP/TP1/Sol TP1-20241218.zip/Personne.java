abstract class Personne {
    protected String nom;

    public Personne(String n) {
    	nom=n;
    }
    void affichage(){

      System.out.println("Nom :"+nom);
    
}
}
