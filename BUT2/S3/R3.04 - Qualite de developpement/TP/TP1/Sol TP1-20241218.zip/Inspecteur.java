
import java.util.Scanner;

public class Inspecteur extends Personne {
    private static Inspecteur inspecteur = null;

    private Inspecteur(String nom) {
       super(nom);
    }

    public void setNom(String nom) {
        this.nom = nom;
    }
    public String getNom() {
        return this.nom;
    }


    public void display() {
        System.out.println("Inspecteur :");
        this.affichage();
    }

    public static synchronized Inspecteur getInspecteur() {
        if (inspecteur == null) {
        	Scanner sc=new Scanner(System.in);
            System.out.println("Enter the Inspector's name");
            String nom = sc.nextLine();
            inspecteur = new Inspecteur(nom);
        }
        return inspecteur;
    }
    
    public static synchronized void modifInspecteur() {
    	if (inspecteur != null) {
    		Scanner sc=new Scanner(System.in);
            System.out.println("Enter the Inspector's name");
            String n = sc.nextLine();
            inspecteur.nom=n;
    	}
    }

    
}


