
public class TP2 {
	public static void main(String[] args) {
        
        Personne etudiant = new Eleve("Wilfried");
        Personne enseignant = new Enseignant("Suzanne");
        etudiant.affichage();
        enseignant.affichage();
        
        Inspecteur lestrade = Inspecteur.getInspecteur();
        lestrade.display();
        Inspecteur.modifInspecteur();
        lestrade.display();
    }
}
