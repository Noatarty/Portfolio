/**
* \file src3.c
* \brief Autres exemples de commentaires Doxygen pour différents aspects du code en C.
* \author VotreNom
* \version 1.0
* \date 7 décembre 2023
*/

#include <stdio.h>

/**
* \def MAX_SIZE
* \brief Taille maximale pour une structure de données.
*/
#define MAX_SIZE 50

/**
* \typedef Data
* \brief Type représentant des données.
*/
typedef struct {
    int id; /*!< Identifiant de données */
    char name[MAX_SIZE]; /*!< Nom associé aux données */
    float value; /*!< Valeur des données */
} Data;

/**
* \fn void afficherDonnees(Data* data)
* \brief Affiche les détails des données.
* \param data : Pointeur vers les données à afficher.
*/
void afficherDonnees(Data* data) {
    printf("ID: %d\n", data->id);
    printf("Nom: %s\n", data->name);
    printf("Valeur: %.2f\n", data->value);
}

int main() {
    Data donnees = {1, "Exemple", 25.5};
    afficherDonnees(&donnees);

    return 0;
}
