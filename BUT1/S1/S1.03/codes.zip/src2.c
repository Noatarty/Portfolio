/**
* \file src2.c
* \brief Exemples supplémentaires de commentaires Doxygen pour différents éléments de code en C.
* \author VotreNom
* \version 1.0
* \date 7 décembre 2023
*/

#include <stdio.h>

/**
* \struct Point
* \brief Structure représentant un point dans un espace 2D.
*/
typedef struct {
    int x; /*!< Coordonnée x du point */
    int y; /*!< Coordonnée y du point */
} Point;

/**
* \fn int calculerDistance(Point p1, Point p2)
* \brief Calcule la distance entre deux points dans un espace 2D.
* \param p1 : Premier point
* \param p2 : Deuxième point
* \return La distance entre les deux points
*/
int calculerDistance(Point p1, Point p2) {
    int distance = sqrt(pow((p2.x - p1.x), 2) + pow((p2.y - p1.y), 2));
    return distance;
}

int main() {
    Point point1 = {0, 0};
    Point point2 = {3, 4};

    int distance = calculerDistance(point1, point2);
    printf("Distance entre les points : %d\n", distance);

    return 0;
}
